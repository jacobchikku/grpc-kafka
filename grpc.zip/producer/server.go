package producer

import (
	"context"
	"fmt"
	"log"
	"net"

	"google.golang.org/grpc"
)

type server struct{}

func (*server) PostData(ctx context.Context, req *SysDataRequest) (*SysDataResponse, error) {
	ServerData := req.GetSysdata().GetInfo()
	result := "Data Saved" + ServerData
	res := &SysDataResponse{
		Response: result,
	}
	return res, nil
}

func main() {
	fmt.Println("Server Running")
	lis, err := net.Listen("tcp", "0.0.0.0:50051")
	if err != nil {
		log.Fatal("Failed to listen", err)
	}

	s := grpc.NewServer()
	RegisterSysDataServiceServer(s, &server{})

	if err := s.Serve(lis); err != nil {
		log.Fatal("Failed to Serve", err)
	}

}
