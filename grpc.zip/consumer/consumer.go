package main

import (
	"fmt"
	"time"

	"github.com/confluentinc/confluent-kafka-go/kafka"
)

//    $ ccloud api-key create

const (
	bootstrapServers = "pkc-ymrq7.us-east-2.aws.confluent.cloud:9092"
	ccloudAPIKey     = "TA2KNOPCXRTNCM5Y"
	ccloudAPISecret  = "N4QNIFIdWVCa4MP4ueMeF5dfuVk3PYYGKrdbHaaMjrwnzSN/yi2ySys252paN3UO"
)

func main() {
	topic := "CPU-Usage"
	// Now consumes the record and print its value...
	consumer, err := kafka.NewConsumer(&kafka.ConfigMap{
		"bootstrap.servers":  bootstrapServers,
		"sasl.mechanisms":    "PLAIN",
		"security.protocol":  "SASL_SSL",
		"sasl.username":      ccloudAPIKey,
		"sasl.password":      ccloudAPISecret,
		"session.timeout.ms": 6000,
		"group.id":           "my-group",
		"auto.offset.reset":  "earliest"})

	if err != nil {
		panic(fmt.Sprintf("Failed to create consumer: %s", err))
	}

	topics := []string{topic}
	consumer.SubscribeTopics(topics, nil)

	for {
		message, err := consumer.ReadMessage(100 * time.Millisecond)
		if err == nil {
			fmt.Printf("consumed from topic %s [%d] at offset %v: "+
				string(message.Value), *message.TopicPartition.Topic,
				message.TopicPartition.Partition, message.TopicPartition.Offset)
		}
	}

	consumer.Close()

}
